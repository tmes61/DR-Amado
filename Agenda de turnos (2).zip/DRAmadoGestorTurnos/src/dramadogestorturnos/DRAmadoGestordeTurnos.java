package dramadogestorturnos;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Gestor de Turnos - versión con interfaz Swing
 * Ejecutar en VS Code sin necesidad de package ni carpetas.
 */
public class DRAmadoGestordeTurnos {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GestorTurnos gestor = new GestorTurnos();
            Usuario doctor = new Usuario("dr_amado", "Salvador Amado", RolUsuario.DOCTOR, "1234");
            new GestorTurnosGUI(gestor, doctor);
        });
    }
}

class GestorTurnosGUI extends JFrame {
    private GestorTurnos gestor;
    private Usuario doctor;

    private JTextArea salida;
    private JTextField nombre, apellido, telefono, dni, obraSocial;
    private JTextField fecha, hora, duracion, motivo, idPaciente, idTurno;

    public GestorTurnosGUI(GestorTurnos gestor, Usuario doctor) {
        this.gestor = gestor;
        this.doctor = doctor;

        setTitle("Gestor de Turnos - Dr. Amado");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Registrar Paciente", panelRegistrar());
        tabs.add("Listar Pacientes", panelListarPacientes());
        tabs.add("Agendar Turno", panelAgendar());
        tabs.add("Agenda del Día", panelAgenda());
        tabs.add("Cancelar Turno", panelCancelar());

        add(tabs);
        setVisible(true);
    }

    private JPanel panelRegistrar() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 5, 5));
        panel.add(new JLabel("Nombre:"));
        nombre = new JTextField();
        panel.add(nombre);

        panel.add(new JLabel("Apellido:"));
        apellido = new JTextField();
        panel.add(apellido);

        panel.add(new JLabel("Teléfono:"));
        telefono = new JTextField();
        panel.add(telefono);

        panel.add(new JLabel("DNI:"));
        dni = new JTextField();
        panel.add(dni);

        panel.add(new JLabel("Obra Social:"));
        obraSocial = new JTextField();
        panel.add(obraSocial);

        JButton registrar = new JButton("Registrar");
        registrar.addActionListener(e -> {
            gestor.registrarPaciente(
                    nombre.getText(), apellido.getText(),
                    telefono.getText(), dni.getText(), obraSocial.getText());
            JOptionPane.showMessageDialog(this, "Paciente registrado correctamente ✅");
            nombre.setText("");
            apellido.setText("");
            telefono.setText("");
            dni.setText("");
            obraSocial.setText("");
        });
        panel.add(new JLabel());
        panel.add(registrar);
        return panel;
    }

    private JPanel panelListarPacientes() {
        JPanel panel = new JPanel(new BorderLayout());
        salida = new JTextArea();
        salida.setEditable(false);
        JButton refrescar = new JButton("Actualizar lista");
        refrescar.addActionListener(e -> {
            salida.setText("");
            if (gestor.getPacientes().isEmpty()) {
                salida.setText("No hay pacientes registrados.");
            } else {
                salida.append("Pacientes:\n");
                gestor.getPacientes().forEach((id, p) -> {
                    salida.append(String.format("[%s] %s %s (DNI: %s, OS: %s)\n",
                            id.toString().substring(0, 8),
                            p.getNombre(), p.getApellido(), p.getDni(), p.getObraSocial()));
                });
            }
        });
        panel.add(new JScrollPane(salida), BorderLayout.CENTER);
        panel.add(refrescar, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel panelAgendar() {
        JPanel panel = new JPanel(new GridLayout(8, 2, 5, 5));
        panel.add(new JLabel("ID Paciente (8 chars):"));
        idPaciente = new JTextField();
        panel.add(idPaciente);

        panel.add(new JLabel("Fecha (DD/MM/YYYY):"));
        fecha = new JTextField();
        panel.add(fecha);

        panel.add(new JLabel("Hora (HH:MM):"));
        hora = new JTextField();
        panel.add(hora);

        panel.add(new JLabel("Duración (min):"));
        duracion = new JTextField();
        panel.add(duracion);

        panel.add(new JLabel("Motivo:"));
        motivo = new JTextField();
        panel.add(motivo);

        JButton agendar = new JButton("Agendar Turno");
        agendar.addActionListener(e -> {
            try {
                UUID pacienteUUID = gestor.buscarPacientePorIdParcial(idPaciente.getText());
                DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate f = LocalDate.parse(fecha.getText(), formato);
                LocalTime h = LocalTime.parse(hora.getText());
                int dur = Integer.parseInt(duracion.getText());

                gestor.reservarTurno(doctor, pacienteUUID, LocalDateTime.of(f, h), dur, motivo.getText());
                JOptionPane.showMessageDialog(this, "Turno agendado correctamente ✅");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
        panel.add(new JLabel());
        panel.add(agendar);
        return panel;
    }

    private JPanel panelAgenda() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextField fechaConsulta = new JTextField();
        JButton ver = new JButton("Ver agenda");
        JTextArea area = new JTextArea();
        area.setEditable(false);

        ver.addActionListener(e -> {
            try {
                DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate f = LocalDate.parse(fechaConsulta.getText(), formato);
                area.setText(gestor.obtenerAgendaTexto(f));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Fecha inválida.");
            }
        });

        JPanel top = new JPanel(new BorderLayout());
        top.add(new JLabel("Fecha (DD/MM/YYYY): "), BorderLayout.WEST);
        top.add(fechaConsulta, BorderLayout.CENTER);
        top.add(ver, BorderLayout.EAST);

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        return panel;
    }

    private JPanel panelCancelar() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.add(new JLabel("ID Turno (8 chars):"));
        idTurno = new JTextField();
        panel.add(idTurno);

        JButton cancelar = new JButton("Cancelar");
        cancelar.addActionListener(e -> {
            try {
                UUID turnoUUID = gestor.buscarTurnoPorIdParcial(idTurno.getText());
                gestor.cancelarTurno(turnoUUID);
                JOptionPane.showMessageDialog(this, "Turno cancelado correctamente 🗑️");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
        panel.add(new JLabel());
        panel.add(cancelar);
        return panel;
    }
}

// ===========================
// CLASES DE DATOS Y LÓGICA
// ===========================

enum RolUsuario {
    DOCTOR, ASISTENTE, ADMIN
}

class Usuario {
    private UUID id;
    private String nombreUsuario;
    private String nombre;
    private RolUsuario rol;
    private String password;

    public Usuario(String nombreUsuario, String nombre, RolUsuario rol, String password) {
        this.id = UUID.randomUUID();
        this.nombreUsuario = nombreUsuario;
        this.nombre = nombre;
        this.rol = rol;
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public RolUsuario getRol() {
        return rol;
    }
}

class Paciente {
    private UUID id;
    private String nombre;
    private String apellido;
    private String telefono;
    private String dni;
    private String obraSocial;

    public Paciente(String nombre, String apellido, String telefono, String dni, String obraSocial) {
        this.id = UUID.randomUUID();
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.dni = dni;
        this.obraSocial = obraSocial;
    }

    public UUID getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDni() {
        return dni;
    }

    public String getObraSocial() {
        return obraSocial;
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " (DNI: " + dni + ", OS: " + obraSocial + ")";
    }
}

enum EstadoTurno {
    CONFIRMADO, CANCELADO
}

class Turno {
    private UUID id;
    private Paciente paciente;
    private Usuario doctor;
    private LocalDateTime fechaHora;
    private int duracion;
    private String motivo;
    private EstadoTurno estado;

    public Turno(Paciente paciente, Usuario doctor, LocalDateTime fechaHora, int duracion, String motivo) {
        this.id = UUID.randomUUID();
        this.paciente = paciente;
        this.doctor = doctor;
        this.fechaHora = fechaHora;
        this.duracion = duracion;
        this.motivo = motivo;
        this.estado = EstadoTurno.CONFIRMADO;
    }

    public UUID getId() {
        return id;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public int getDuracion() {
        return duracion;
    }

    public EstadoTurno getEstado() {
        return estado;
    }

    public void setEstado(EstadoTurno e) {
        this.estado = e;
    }

    @Override
    public String toString() {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return String.format("[%s] %s - %s (%s) [%s]",
                id.toString().substring(0, 8),
                fechaHora.format(f),
                paciente.getNombre() + " " + paciente.getApellido(),
                motivo,
                estado);
    }
}

class GestorTurnos {
    private Map<UUID, Paciente> pacientes = new HashMap<>();
    private Map<UUID, Turno> turnos = new HashMap<>();

    public Map<UUID, Paciente> getPacientes() {
        return pacientes;
    }

    public Paciente registrarPaciente(String nombre, String apellido, String telefono, String dni, String obraSocial) {
        Paciente p = new Paciente(nombre, apellido, telefono, dni, obraSocial);
        pacientes.put(p.getId(), p);
        return p;
    }

    public UUID buscarPacientePorIdParcial(String idParcial) {
        return pacientes.keySet().stream()
                .filter(id -> id.toString().startsWith(idParcial))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Paciente no encontrado"));
    }

    public UUID buscarTurnoPorIdParcial(String idParcial) {
        return turnos.keySet().stream()
                .filter(id -> id.toString().startsWith(idParcial))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Turno no encontrado"));
    }

    public void cancelarTurno(UUID id) {
        Turno t = turnos.get(id);
        if (t == null)
            throw new IllegalArgumentException("Turno no encontrado");
        t.setEstado(EstadoTurno.CANCELADO);
    }

    // ✅ MÉTODO CORREGIDO
    public Turno reservarTurno(Usuario doctor, UUID pacienteId, LocalDateTime fechaHora, int duracion, String motivo) {
        Paciente p = pacientes.get(pacienteId);
        if (p == null)
            throw new IllegalArgumentException("Paciente no encontrado");

        // 🚫 Validar superposición de turnos
        for (Turno t : turnos.values()) {
            if (t.getEstado() == EstadoTurno.CANCELADO)
                continue; // Ignorar cancelados

            LocalDateTime inicio = t.getFechaHora();
            LocalDateTime fin = inicio.plusMinutes(t.getDuracion());
            LocalDateTime nuevoFin = fechaHora.plusMinutes(duracion);

            boolean seSolapan = fechaHora.isBefore(fin) && nuevoFin.isAfter(inicio);
            if (seSolapan) {
                throw new IllegalArgumentException("Ya existe un turno en ese horario ⛔");
            }
        }

        Turno t = new Turno(p, doctor, fechaHora, duracion, motivo);
        turnos.put(t.getId(), t);
        return t;
    }

    public String obtenerAgendaTexto(LocalDate fecha) {
        StringBuilder sb = new StringBuilder();
        turnos.values().stream()
                .filter(t -> t.getFechaHora().toLocalDate().equals(fecha))
                .sorted(Comparator.comparing(Turno::getFechaHora))
                .forEach(t -> sb.append(t).append("\n"));
        if (sb.length() == 0)
            sb.append("No hay turnos para este día.");
        return sb.toString();
    }
}
